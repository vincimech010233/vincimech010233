# Original README: English translation (Tails)

[Original Spanish text](README_ORIGINAL.md) · [Current English guide](README.en.md)

This is a translation of the preserved original README, not an updated validation claim. Consult the current guide and verification notes for reviewed limitations.

# Tails OS + VMware version (without modifying Tor Browser)

**NOTICE:** Tails does not provide a ready-to-use automated Playwright/Chromium installation out of the box. Dynamic analysis runs **only** if Playwright and its Chromium are already available. Installing or modifying Tor Browser for this purpose is not recommended. If these dependencies are unavailable, the program generates static HTTP analysis through the Tor SOCKS proxy and explicitly records the dynamic failure.

1. Run only in a disposable Tails VM, without VMware integration with the host or credentials; do not enable an alternative direct connection.
2. Check the SOCKS port in your Tails configuration (it may vary). The socket detector **does not prove** that the service is actually Tor.
3. From a terminal:

```bash
python3 analizar.py 'https://ejemplo.org' --modo tails --tor-puerto 9050 --salida resultado
```

If you only need static analysis, add `--sin-dinamico`.

Open `resultado/informe.html` with a local viewer, or read `resultado/contenido_visible.txt` if present. The HTML report uses restrictive CSP and escaped content.

The page is actually visited. GET can reveal data even without POST; absolute anonymity or security is not guaranteed. The script does not modify Tor Browser.
