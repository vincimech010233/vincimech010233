# Versión Tails OS + VMware (sin tocar Tor Browser)

**AVISO:** Tails no ofrece un Playwright/Chromium automatizable listo de fábrica. El análisis dinámico **solo** se ejecutará si Playwright y su Chromium ya están disponibles. No recomendamos instalar o modificar Tor Browser para conseguirlo. Si no lo están, el programa genera análisis HTTP estático mediante SOCKS Tor y señala explícitamente el fallo dinámico.

1. Ejecutar únicamente en una VM de Tails desechable, sin integración de VMware con el anfitrión ni credenciales; no habilitar navegación directa alternativa.
2. Verifique el puerto SOCKS en su Tails (puede variar). El detector de socket **no prueba** que realmente sea Tor.
3. Desde terminal:

```bash
python3 analizar.py 'https://ejemplo.org' --modo tails --tor-puerto 9050 --salida resultado
```

Si solo necesita estático, agregue `--sin-dinamico`.

Abra `resultado/informe.html` con el visor local o lea `resultado/contenido_visible.txt` si existe. El informe HTML tiene CSP restrictiva y contenido escapado.

La página se visita realmente. GET puede revelar datos incluso sin POST; no se garantiza anonimato o seguridad absoluta. No modifica Tor Browser.
