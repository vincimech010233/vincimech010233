# Original README: English translation (Linux)

[Original Spanish text](README_ORIGINAL.md) · [Current English guide](README.en.md)

This is a translation of the preserved original README, not an updated validation claim. Consult the current guide and verification notes for reviewed limitations.

# Disposable Linux + VMware version (dynamic)

Use a dedicated VM without shared folders, clipboard, credentials, or access to the local network. Ideally, use a network with controlled outbound access and filtering of private networks; **VMware NAT alone does not provide sufficient isolation**. Create a snapshot beforehand and destroy the VM afterward.

Preparation in a Debian/Ubuntu Linux VM (with network access only to install dependencies from trusted sources):

```bash
sudo apt update
sudo apt install -y python3-venv curl
python3 -m venv .venv
.venv/bin/pip install playwright
.venv/bin/python -m playwright install --with-deps chromium
```

Execution:

```bash
.venv/bin/python analizar.py 'https://ejemplo.org' --modo linux --salida resultado --segundos 15
```

Viewing: open `resultado/informe.html` locally; evidence includes `resultado/informe.json`, `resultado/contenido_visible.txt`, `resultado/captura.png`, and `resultado/dom.html.txt`.

The browser executes JavaScript and makes real requests, including GET and POST. It does NOT block exfiltration. Strict external filtering is recommended; do not introduce real data and disable LAN/host access. There is no kernel, memory, or system-call capture; this is dynamic browser analysis, not a complete malware sandbox.
