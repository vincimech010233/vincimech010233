# Versión Linux desechable + VMware (dinámico)

Utilizar una VM dedicada, sin carpetas compartidas, portapapeles, credenciales ni acceso a la red local. Idealmente, red con salida controlada y filtrado de acceso a redes privadas; **NAT de VMware por sí solo no es aislamiento suficiente**. Crear instantánea antes y destruir la VM después.

Preparación en VM Linux Debian/Ubuntu (con red solo para instalar dependencias desde repositorios confiables):

```bash
sudo apt update
sudo apt install -y python3-venv curl
python3 -m venv .venv
.venv/bin/pip install playwright
.venv/bin/python -m playwright install --with-deps chromium
```

Ejecución:

```bash
.venv/bin/python analizar.py 'https://ejemplo.org' --modo linux --salida resultado --segundos 15
```

Visualización: abrir localmente `resultado/informe.html`; evidencia `resultado/informe.json`, `resultado/contenido_visible.txt`, `resultado/captura.png`, `resultado/dom.html.txt`.

El navegador ejecuta JavaScript y realiza peticiones reales, incluidos GET y POST. NO bloquea exfiltración. Se recomienda filtrado externo estricto, no introducir datos reales y desactivar acceso a LAN/host. No hay captura del kernel, memoria ni llamadas de sistema; análisis dinámico de navegador, no sandbox de malware completo.
